import React from "react";

export default class paymentProcess extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    return <div>inside Payment Process</div>;
  }
}
