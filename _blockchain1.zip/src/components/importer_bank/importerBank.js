import React from "react";
import SaleAgreement from "./../sale_agreement/saleAgreement.js";

export default class ImporterBank extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      formSubmitted: false
    };
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleClick = this.handleClick.bind(this);
  }

  handleSubmit() {
    this.props.updateStep(3);

    this.setState({
      formSubmitted: true
    });
  }

  handleClick() {
    this.props.updateTimeline(60);
  }
  render() {
    switch (this.state.formSubmitted) {
      case false:
        return (
          <div>
            <div>inside Importer Bank</div>
            <div
              className="btn btn-primary btn-block"
              type="submit"
              onClick={this.handleClick}
            >
              Check
            </div>
            <div
              className="btn btn-primary btn-block"
              type="submit"
              onClick={this.handleSubmit}
            >
              Submit
            </div>
          </div>
        );

      case true:
        return <SaleAgreement updateStep={this.props.updateStep}/>;
    }
  }
}
