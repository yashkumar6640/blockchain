import React from "react";
import BillOfExchange from "./../bill_of_exchange/billOfExchange.js";

export default class CustomsUSA extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      formSubmitted: false
    };
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleSubmit() {
    this.props.updateStep(5);
    this.setState({
      formSubmitted: true
    });
  }
  render() {
    switch (this.state.formSubmitted) {
      case false:
        return (
          <div>
            <form>
              <div className="form-group">
                <div>UUID</div>
                <div>
                  <input className="form-input" />
                </div>
              </div>
              <div className="form-group">
                <div>Step</div>
                <div>
                  <input className="form-input" />
                </div>
              </div>
              <div className="form-group">
                <div>Status</div>
                <div>
                  <input className="form-input" />
                </div>
              </div>
              <div className="form-group">
                <div>Date Field</div>
                <div>
                  <input className="form-input" />
                </div>
              </div>
              <div className="form-group">
                <div>Customs Cleared</div>
                <div>
                  <input className="form-input" />
                </div>
              </div>
            </form>
            <div>inside CUSTOMS USA Bank</div>
            <div
              className="btn btn-primary btn-block"
              type="submit"
              onClick={this.handleSubmit}
            >
              Submit
            </div>
          </div>
        );

      case true:
        return <BillOfExchange updateStep={this.props.updateStep} />;
    }
  }
}
