import React from "react";
import ImporterBank from "./../importer_bank/importerBank.js";

export default class PORequest extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      formSubmitted: false
    };
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleClick = this.handleClick.bind(this);
  }

  handleSubmit() {
    this.props.updateStep(2);
    this.setState({
      formSubmitted: true
    });
  }
  handleClick() {
    this.props.updateTimeline(50);
  }
  render() {
    switch (this.state.formSubmitted) {
      case false:
        return (
          <div>
            <div>inside PORequest</div>
            <div
              className="btn btn-primary btn-block"
              onClick={this.handleClick}
            >
              Submit
            </div>
            <div
              className="btn btn-primary btn-block"
              type="submit"
              onClick={this.handleSubmit}
            >
              Submit
            </div>
          </div>
        );

      case true:
        return <ImporterBank updateStep={this.props.updateStep} />;
    }
  }
}
