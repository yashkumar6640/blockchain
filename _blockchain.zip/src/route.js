import React from 'react';
import {BrowserRouter as Router, Route, Link } from "react-router-dom"
import About from './components/about/About.js'



const Routes = () => (
    <Router>
      <div>
        <ul>
          <li>
            <Link to='/about'>Inbox</Link>
          </li>
          <li>
              <a href="/about">About</a>
              </li>
          <li>
            <Link to="/starred">Starred</Link>
          </li>
          <li>
            <Link to="/important">Important</Link>
          </li>
          <li>
            <Link to="/sentmail">Sent Mail</Link>
          </li>
          
        </ul>
  
        <hr />
  
        <Route exact path="/" component={Home} />
        {/* <Route path="/about" component={About} /> */}
      </div>
    </Router>
  );
  
  const Home = () => (
    <div>
      <h2>Home</h2>
    </div>
  );
  
//   const About = () => (
//     <div>
//       <h2>About</h2>
//     </div>
//   );

  export default Routes;