import React, { Component } from "react";
import Routes from "./route.js";

import { Switch, Route, Link } from "react-router-dom";
import "./App.css";

import Exporter from "./components/exporter/exporter.js";
import Timeline from "./components/timeline/timeline.js";
import Export from "./components/topdf/topdf.js";

var $ = require("jquery");

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      // users: []
      showTimeline: false,
      showFrontPage: true
    };
  }

  componentWillMount() {
    // $.ajax({
    //   method: "get",
    //   url: "api/fed/users.json",
    //   success: function(response) {
    //     this.setState({
    //       users: response
    //     });
    //   }.bind(this)
    // });
  }

  componentDidMount() {}

  render() {
    return (
      <div>
        <Export />
        <div className={this.state.showFrontPage ? "" : "hide-front-page"}>
          {/* <table className="table table-striped table-hover table-responsive">
          <tbody>
            {this.state.users.map(user => (
              <tr>
                <td style={{ "font-weight": "bold" }}>{user.Key}</td>
                <td style={{ "font-weight": "bold" }}>
                  {user.Record["action"]}
                </td>
              </tr>
            ))}
          </tbody>
        </table> */}

          <div className="col-sm-12 frontpage-navigator">
            <span className="fa fa-money" />
          </div>
          <div className="col-sm-6">
            <div className="col-sm-12 list-box">Hello</div>
            <div className="col-sm-12 list-box">
              <div className="text-center">
                <span>Blockchain</span>
              </div>
            </div>
          </div>
          <div className="col-sm-6">
            <Exporter />
          </div>
        </div>
        <div
          className={
            this.state.showTimeline ? "timeline-show" : "timeline-hide"
          }
        >
          <Timeline />
        </div>
      </div>
    );
  }
}

export default App;
