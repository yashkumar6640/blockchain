import React from "react";

export default class NewMail extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      to: "",
      cc: "",
      message: "",
      subject: "",
      time: "2:30 pm"
    };
    this.handleSubmit = this.handleSubmit.bind(this);
    this.handleChange = this.handleChange.bind(this);
  }
  handleSubmit() {
    alert("here");
    console.log(this.state.to, this.statesubject, this.state.time);
    if (this.state.to && this.state.message) {
      var db = this.props.db;
      var request = db
        .transaction(["sentMail"], "readwrite")
        .objectStore("sentMail")
        .add({
          name: this.state.to,
          subject: this.state.subject,
          toa: this.state.time
        });
    }
  }
  handleChange(e) {
    console.log(e.target.value);
    if (e.target.name === "email") {
      this.setState({
        to: e.target.value
      });
    } else if (e.target.name === "cc") {
      this.setState({
        cc: e.target.value
      });
    } else if (e.target.name === "subject") {
      this.setState({
        subject: e.target.value
      });
    } else if (e.target.name === "msg") {
      this.setState({
        message: e.target.value
      });
    }
  }

  render() {
    return (
      <div id="newmailform" className="container">
        <h2>New Message</h2>
        <form action="javascript:;" onSubmit={this.handleSubmit}>
          <div className="form-group">
            <label for="email">To:</label>
            <input
              type="email"
              className="form-control"
              id="email"
              placeholder="Enter email"
              name="email"
              onChange={this.handleChange}
            />
          </div>
          <div className="form-group">
            <label for="cc">cc:</label>
            <input
              type="email"
              className="form-control"
              id="cc"
              placeholder="Enter Recipients"
              name="cc"
              onChange={this.handleChange}
            />
          </div>
          <div className="form-group">
            <label for="subject">Subject:</label>
            <input
              type="text"
              className="form-control"
              id="subject"
              placeholder="Enter Subject"
              name="subject"
              onChange={this.handleChange}
            />
          </div>
          <div className="form-group">
            <label for="msg">Message:</label>
            <textarea
              type="text"
              className="form-control"
              id="msg"
              rows="5"
              placeholder="Enter Message"
              name="msg"
              onChange={this.handleChange}
            />
          </div>
          <div className="checkbox">
            <label>
              <input type="checkbox" name="remember" /> Remember me
            </label>
          </div>
          <button type="submit" className="btn btn-default">
            Submit
          </button>
        </form>
      </div>
    );
  }
}
