import React from "react";

export default class Starred extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      starredMail: [{}]
    };
  }

  componentWillMount() {
    var that = this;
    var db = this.props.db;
    var transaction = db.transaction(["star"]);
    var objectStore = transaction.objectStore("star");
    var request = objectStore.getAll();

    request.onerror = function(event) {
      alert("Error on reading");
    };

    request.onsuccess = function(event) {
      if (request.result) {
        that.setState({
          starredMail: request.result
        });
      } else {
        alert("No found in database");
      }
    };
  }

  render() {
    return (
      <div>
        <table className="table table-striped table-hover table-responsive">
          <tbody>
            {" "}
            {this.state.starredMail.map(mail => (
              <tr>
                <td
                  style={{
                    "font-weight": "bold"
                  }}
                >
                  {" "}
                  {mail.name}{" "}
                </td>{" "}
                <td
                  style={{
                    "font-weight": "bold"
                  }}
                >
                  {" "}
                  {mail.subject}{" "}
                </td>{" "}
                <td
                  style={{
                    "font-weight": "bold"
                  }}
                >
                  {" "}
                  {mail.toa}{" "}
                </td>{" "}
              </tr>
            ))}{" "}
          </tbody>{" "}
        </table>
      </div>
    );
  }
}
