import React from "react";
var $ = require("jquery");

export default class SentMail extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      mails: [{}]
    };
  }

  componentWillMount() {
    var that = this;
    var db = this.props.db;
    var transaction = db.transaction(["sentMail"]);
    var objectStore = transaction.objectStore("sentMail");
    var request = objectStore.getAll();

    request.onerror = function(event) {
      alert("Error on reading");
    };

    request.onsuccess = function(event) {
      if (request.result) {
        that.setState({
          mails: request.result
        });
      } else {
        alert("No found in database");
      }
    };
  }
  componentDidMount() {
    // var that = this;
    // $.ajax({
    //     method: 'get',
    //     url: './api/inbox/data.json',
    //     success: function (response) {
    //         that.setState({
    //             mails: response
    //         })
    //     }
    // })
  }
  render() {
    return (
      <div>
        <input className="form-control" placeholder="Seach in Inbox" />
        <table className="table table-striped table-hover table-responsive">
          <tbody>
            {this.state.mails.map(mail => (
              <tr>
                <td style={{ "font-weight": "bold" }}>To: {mail.name}</td>
                <td style={{ "font-weight": "bold" }}>{mail.subject}</td>
                <td style={{ "font-weight": "bold" }}>{mail.toa}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  }
}
