import React from 'react'
import './Home.css'

export default class Home extends React.Component{
    constructor(props){
        super(props);

    }

    componentDidMount(){
      
    }
    render(){
        return(<div><p>Inside Home Component</p></div>)
    }
}