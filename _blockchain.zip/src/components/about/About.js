import React from 'react'

export default class About extends React.Component{
    render(){
        return(<div>I am in About component</div>)
    }
}