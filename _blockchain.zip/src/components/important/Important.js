import React from "react";

export default class Important extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      important: [{}],
      db: {}
    };
  }

  componentWillMount() {
    var that = this;
    var db = this.props.db;
    var transaction = db.transaction(["important"]);
    var objectStore = transaction.objectStore("important");
    var request = objectStore.getAll();

    request.onerror = function(event) {
      alert("Error on reading");
    };

    request.onsuccess = function(event) {
      if (request.result) {
        that.setState({
          important: request.result
        });
      } else {
        alert("No found in database");
      }
    };
  }

  render() {
    return (
      <div>
        <table className="table table-striped table-hover table-responsive">
          <tbody>
            {this.state.important.map(mail => (
              <tr>
                <td style={{ "font-weight": "bold" }}>{mail.name}</td>
                <td style={{ "font-weight": "bold" }}>{mail.subject}</td>
                <td style={{ "font-weight": "bold" }}>{mail.toa}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  }
}
