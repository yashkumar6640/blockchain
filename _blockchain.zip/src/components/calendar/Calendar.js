import React from 'react'

export default class Calendar extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            dates : [1,2,3,4,5,6,7,8,9,10]
        }
    }
    render(){
        return(
            <div style={{"margin":"60px 0"}}>
                <p className="text-info lead text-center">Calendar</p>
                <table className="table table-striped table-hover table-responsive">
                <tbody>
                    <tr>
                        {this.state.dates.map((date)=>
                        (
                            <td><span className="col-sm-1">{date}</span></td>
                        ))}
                        </tr>
                    
                       
                  
                    </tbody>

                </table>
            </div>
        )
    }
}