import React from "react";
var $ = require("jquery");

export default class Inbox extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      mails: [{}]
    };
  }
  componentWillMount() {
    var that = this;
    var db = this.props.db;
    var transaction = db.transaction(["inbox"]);
    var objectStore = transaction.objectStore("inbox");
    var request = objectStore.getAll();

    request.onerror = function(event) {
      alert("Error on reading");
    };

    request.onsuccess = function(event) {
      if (request.result) {
        that.setState({
          mails: request.result
        });
      } else {
        alert("No found in database");
      }
    };
  }

  componentDidMount() {}

  add(name, subject, toa, e, type) {
    var db = this.props.db;
    console.log(db);
    var request = db
      .transaction([type], "readwrite")
      .objectStore(type)
      .add({ name: name, subject: subject, toa: toa });

    var inboxRequest = db.transaction(["inbox"], "readwrite");
    var os = inboxRequest.objectStore("inbox");

    os.openCursor().onsuccess = function(event) {
      var cursor = event.target.result;
      if (cursor) {
        console.log(name, cursor.value.name);
        if (cursor.value.name === name) {
          var updateData = cursor.value;
          updateData[type] === true
            ? (updateData[type] = false)
            : (updateData[type] = true);

          //   updateData[type] = true;
          console.log(updateData);
          var request = cursor.update(updateData);
          request.onsuccess = function() {
            console.log("added type");
          };
        }
        cursor.continue();
      } else {
        console.log("Entries Displayed");
      }
    };
    os.openCursor().onerror = function(event) {
      console.log(event);
    };
    request.onsuccess = function(event) {
      console.log("added");
    };

    request.onerror = function(event) {
      console.log("failure");
    };
  }

  render() {
    return (
      <div>
        <input className="form-control" placeholder="Search in Inbox" />
        <table className="table table-striped table-hover table-responsive">
          <tbody>
            {this.state.mails.map(mail => (
              <tr>
                <td>
                  <span
                    onClick={e =>
                      this.add(mail.name, mail.subject, mail.toa, e, "star")
                    }
                    className={
                      mail.starred || mail.star
                        ? "glyphicon glyphicon-star"
                        : "glyphicon glyphicon-star-empty"
                    }
                  >
                    {" "}
                  </span>
                </td>
                <td>
                  <span
                    onClick={e =>
                      this.add(
                        mail.name,
                        mail.subject,
                        mail.toa,
                        e,
                        "important"
                      )
                    }
                    className={
                      mail.important ? "importantMarked" : "importantIcon"
                    }
                  >
                    !
                  </span>
                </td>
                <td style={{ "font-weight": "bold" }}>{mail.name}</td>
                <td style={{ "font-weight": "bold" }}>{mail.subject}</td>
                <td style={{ "font-weight": "bold" }}>{mail.toa}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  }
}
